

const CartItem = () => {



  return (
    <div>
        <h4> Name </h4>
        <h5>$ Price</h5>
        <button>Eliminar uno</button>
        <button>Eliminar todo</button>
    </div>
  )
}

export default CartItem