import img1 from "../image/agility-perro-adulto_-_20-kg-3.png"
import img2 from "../image/chalecoperro3.png"
import img3 from "../image/collargato2.png"
import img4 from "../image/royalbuldogfrances3.png"
import img5 from "../image/croquetashumedasgatos3.png"
import img6 from "../image/pedigreCachorro3.png"
import img7 from "../image/whiscas3k3.png"
import img8 from "../image/collarperro2.png"
import img9 from "../image/pilotoperro5.png"
import img10 from "../image/dogChow3.png"
import img11 from "../image/proplanminiperro2.png"
import img12 from "../image/eukanubagato1k-2.png"




const IMAGES = {
    img1,
    img2,
    img3,
    img4,
    img5,
    img6,
    img7,
    img8,
    img9,
    img10,
    img11,
    img12,
}

 export const Ac ={
    alt1:"Agility Adultos 20 KG",
    alt2:"Chaleco para Perro",
    alt3:"Collar para Gato",
    alt4:"Royal Canin Bulldog Frances",
    alt5:"Croquetas Humedas",
    alt6:"Pedigre Cachorro 20 KG",
    alt7:" Whiscas 3KG",
    alt8:"Collar para perro",
    alt9:"Piloto para Perro",
    alt10:"Dog Chow Control de peso 3KG",
    alt11:"Pro Plan Mente Activa 3KG",
    alt12:"Eukanuba Digestion Saludable 3KG", 
}






export default IMAGES
